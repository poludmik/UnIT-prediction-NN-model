import torch.nn as nn
import torch.nn.functional as F

class NN(nn.Module):
    def __init__(self):
        super(NN, self).__init__()

        self.layer_1 = nn.Linear(5, 24)
        self.layer_2 = nn.Linear(24, 24)
        self.layer_out = nn.Linear(24, 1)

    def forward(self, inputs):
        x = self.layer_1(inputs)
        # x = self.layer_2(x)
        x = self.layer_out(x)
        # x = F.sigmoid(x)
        return x